package de.stickmc.ms.manager.modules;

public class FriendModule {
}
