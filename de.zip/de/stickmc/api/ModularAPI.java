package de.stickmc.api;

public class ModularAPI {
}
